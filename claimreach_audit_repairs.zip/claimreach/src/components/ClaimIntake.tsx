"use client";
import { useState, useMemo, useEffect, useRef } from "react";
import { INTAKE, intakeForType, segmentsForType, segmentsFrom, fieldVisible } from "@/lib/questionnaire";
import FieldRenderer from "./FieldRenderer";
import PropertyLookup, { type ResolvedProperty } from "./PropertyLookup";
import { dbRowToFormValues, dbRowToResolved } from "@/lib/claim-properties";
import CalendlyEmbed from "./CalendlyEmbed";

const PROP_FIELDS = INTAKE.filter((f) => f.scope === "property");

interface PropertyState { _key: string; resolved?: ResolvedProperty; values: Record<string, any>; }

export default function ClaimIntake({
  claimId, firmId, initialAnswers, initialProperties, claimantName, claimantEmail, claimType, leadId, customFields, onSnapshot,
}: {
  claimId: string; firmId: string;
  initialAnswers: Record<string, any>; initialProperties: any[];
  claimantName?: string; claimantEmail?: string; claimType?: string; leadId?: string;
  customFields?: import("@/lib/questionnaire").Field[];
  /** Bubbles the live answers/properties up so a Guided/All-sections switch never remounts stale data. */
  onSnapshot?: (answers: Record<string, any>, props: any[]) => void;
}) {
  const segments = useMemo(
    () => customFields && customFields.length ? segmentsFrom(customFields) : segmentsForType(claimType ?? "motel_trafficking"),
    [claimType, customFields]
  );
  const steps = useMemo(
    () => [...segments.map((s) => ({ id: s.id, title: s.title })), { id: "schedule", title: "Schedule" }],
    [segments]
  );

  const [step, setStep] = useState(0);
  const [autoAdvance, setAutoAdvance] = useState(true);
  const [advanceBanner, setAdvanceBanner] = useState(false);
  const [autofillFeeds, setAutofillFeeds] = useState<Record<string, string>>({});
  useEffect(() => {
    if (!leadId) return;
    (async () => {
      try { const d = await (await fetch(`/api/retainer-autofill-map?lead_id=${leadId}`)).json(); setAutofillFeeds(d.feeds ?? {}); } catch {}
    })();
  }, [leadId]);
  const [viewAll, setViewAll] = useState(false);
  const [locked, setLocked] = useState(true);
  const [scheduled, setScheduled] = useState(false);
  const [finishing, setFinishing] = useState(false);
  const [answers, setAnswers] = useState<Record<string, any>>(initialAnswers || {});
  const [props, setProps] = useState<PropertyState[]>(
    (initialProperties || []).map((p: any, i) => (p && p.values && !p.claim_id
      ? { _key: `p${i}`, values: p.values, resolved: p.resolved } // live runner shape from the other surface
      : { _key: `p${i}`, values: dbRowToFormValues(p), resolved: dbRowToResolved(p) }))
  );
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { onSnapshot?.(answers, props); }, [answers, props]); // eslint-disable-line react-hooks/exhaustive-deps

  // A section is the "property section" if it contains the property_lookup
  // widget. Detecting by content (not a hardcoded id) means imported/beta forms
  // like Beta Motel get the Google finder + add-multiple UI too, regardless of
  // what their section id is.
  const propSectionIds = useMemo(() => {
    const ids = new Set<string>();
    for (const seg of segments) {
      if (seg.fields.some((f: any) => f.kind === "property_lookup" || f.scope === "property")) ids.add(seg.id);
    }
    // Back-compat: the built-in form uses this id explicitly.
    ids.add("s_properties");
    return ids;
  }, [segments]);
  const isProps = (id: string) => propSectionIds.has(id);
  // The property questions for THIS form (built-in or imported/beta). Drives what
  // PropertyCard renders per hotel, so Beta Motel shows its own property fields.
  const propFields = useMemo(() => {
    const fs: any[] = [];
    for (const seg of segments) for (const f of seg.fields) {
      if ((f.scope === "property" || f.kind === "property_lookup") && f.kind !== "section" && f.kind !== "script") fs.push(f);
    }
    return fs.length ? fs : PROP_FIELDS;
  }, [segments]);
  const isSchedule = (id: string) => id === "schedule";
  // Global question numbers — every answerable question across the whole intake gets
  // a sequential number so agents can say "read question 5 verbatim".
  const qNum = useMemo(() => {
    const map: Record<string, number> = {};
    let n = 0;
    for (const seg of segments) for (const f of seg.fields) {
      // Number every question the AGENT answers. Sections and read-aloud scripts
      // are not questions, so they're skipped. Gates ARE questions (Yes/No), so
      // they get numbered too — keeps the on-screen sequence clean and continuous.
      if (!["section", "script"].includes(f.kind)) { n += 1; map[f.id] = n; }
    }
    return map;
  }, [segments]);
  const curStep = steps[step];
  const curSegment = segments.find((s) => s.id === curStep.id);

  // Live completion counter across the ENTIRE intake. Total answerable questions
  // vs how many are still blank, so the agent and QA always know exactly how much
  // is left. Property-scope questions count once per property added.
  const completion = useMemo(() => {
    const isBlank = (v: any) => v === undefined || v === null || v === "" || (Array.isArray(v) && v.length === 0);
    let total = 0, answered = 0;
    for (const seg of segments) {
      for (const f of seg.fields) {
        if (["section", "script"].includes(f.kind)) continue;
        if (f.scope === "property" || f.kind === "property_lookup") {
          // Count property questions across each property block the agent added.
          const blocks = props.length || 0;
          if (f.kind === "property_lookup") {
            total += Math.max(1, blocks);
            for (const p of props) if (!isBlank(p.values?.name_as_recalled) || p.resolved) answered += 1;
          } else {
            total += blocks;
            for (const p of props) if (!isBlank(p.values?.[f.id])) answered += 1;
          }
        } else {
          total += 1;
          if (!isBlank(answers[f.id])) answered += 1;
        }
      }
    }
    return { total, answered, remaining: Math.max(0, total - answered) };
  }, [segments, answers, props]);

  // Auto-advance: when the current section becomes fully answered (and it's not the
  // last step), show a cancelable banner, then move to the next section. The banner
  // gives the agent a grace window so the screen never jumps mid-thought.
  const advanceTimer = useRef<any>(null);
  useEffect(() => {
    if (advanceTimer.current) { clearTimeout(advanceTimer.current); advanceTimer.current = null; }
    if (!autoAdvance || locked || step >= steps.length - 1) { setAdvanceBanner(false); return; }
    // Never auto-advance the Properties or Schedule steps: adding a property or
    // setting a callback is ongoing work, so "answered" there is not a signal to
    // jump. The agent moves on with Save & next when they are ready.
    if (isProps(curStep.id) || isSchedule(curStep.id)) { setAdvanceBanner(false); return; }
    if (segAnswered(curStep.id)) {
      setAdvanceBanner(true);
      advanceTimer.current = setTimeout(() => { setAdvanceBanner(false); setStep((s) => Math.min(s + 1, steps.length - 1)); }, 2500);
    } else {
      setAdvanceBanner(false);
    }
    return () => { if (advanceTimer.current) clearTimeout(advanceTimer.current); };
  }, [answers, props, scheduled, step, autoAdvance, locked]);

  function setVal(id: string, v: any) { setAnswers((s) => ({ ...s, [id]: v })); }

  // Autosave: when unlocked, persist a moment after the last change. No manual
  // Save needed — the pencil unlocks, edits flow, autosave handles the rest.
  const firstRun = useRef(true);
  const saveTimer = useRef<any>(null);
  // Leaving the surface (switching case tabs or Guided/All sections) used to
  // drop an edit made in the last second: the debounce timer was cleared and
  // nothing fired. Flush on unmount instead (Astra audit, Sep 27).
  const flushRef = useRef<() => void>(() => {});
  useEffect(() => () => { flushRef.current(); }, []);
  useEffect(() => {
    if (locked) return;                 // locked = read-only, never autosave
    if (firstRun.current) { firstRun.current = false; return; }
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => { saveTimer.current = null; save(false); }, 1000);
    flushRef.current = () => { if (saveTimer.current) { clearTimeout(saveTimer.current); saveTimer.current = null; void save(false); } };
    return () => { if (saveTimer.current) clearTimeout(saveTimer.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [answers, props, locked]);
  function addProperty() { setProps((s) => [...s, { _key: `p${Date.now()}`, values: {} }]); }
  function removeProperty(k: string) { setProps((s) => s.filter((p) => p._key !== k)); }
  function setPropVal(k: string, id: string, v: any) {
    setProps((s) => s.map((p) => (p._key === k ? { ...p, values: { ...p.values, [id]: v } } : p)));
  }
  function resolveProp(k: string, r: ResolvedProperty) {
    setProps((s) => s.map((p) => p._key === k ? {
      ...p, resolved: r,
      values: { ...p.values, place_id: r.place_id, name_as_recalled: r.name, address: r.address,
        lat: r.lat, lng: r.lng, current_brand: r.current_brand,
        remembered_brand: p.values.remembered_brand ?? "Motel 6", landmarks: r.landmarks ?? p.values.landmarks ?? "" },
    } : p));
  }

  function isFilled(v: any) {
    return v !== undefined && v !== null && v !== "" && !(Array.isArray(v) && v.length === 0);
  }

  function segAnswered(segId: string): boolean {
    // A property section is done when every added property is identified and
    // its questions are answered — an empty row is not a finished section.
    if (isProps(segId)) return props.length > 0 && props.every((p) =>
      (p.resolved || isFilled(p.values?.name_as_recalled)) &&
      propFields.filter((f: any) => f.kind !== "property_lookup").every((f: any) => isFilled(p.values?.[f.id])));
    if (isSchedule(segId)) return scheduled;
    const seg = segments.find((s) => s.id === segId);
    if (!seg) return false;
    // Only count real input fields that are currently VISIBLE (skip scripts/gates/
    // sections and any conditional fields hidden by current answers).
    const inputs = seg.fields.filter((f) => !["script", "section", "gate"].includes(f.kind) && fieldVisible(f, answers));
    // A section with no inputs (e.g. Closing = statement only) is complete by default.
    if (inputs.length === 0) return true;
    // Complete only when every visible input field is filled.
    return inputs.every((f) => isFilled(answers[f.id]));
  }

  const [dqPick, setDqPick] = useState(false);
  const [dqReasons, setDqReasons] = useState<any[]>([]);
  useEffect(() => {
    (async () => {
      try {
        const d = await (await fetch("/api/dq-reasons")).json();
        setDqReasons(d.reasons ?? d ?? []);
      } catch {}
    })();
  }, []);

  async function finishWithStatus(status: string, dqReasonKey: string | null = null) {
    // The status model requires a reason for any disqualifying status. It used to
    // be a window.prompt asking the agent to TYPE one of nine english keys from
    // memory, which is unusable on a live call and worse for an agent working in
    // a second language: a typo silently became an invalid reason. It is a list
    // now, and the list is the only way through.
    if (status === "dq" && !dqReasonKey) return;
    setSaving(true);
    await save(false);
    try {
      const r = await fetch("/api/claims", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ op: "status", claim_id: claimId, status, dq_reason_key: dqReasonKey }),
      });
      if (!r.ok) {
        const d = await r.json().catch(() => ({}));
        setErr(d.error || "Could not set status");
        setSaving(false);
        return; // stay on the page so the disposition is not silently lost
      }
    } catch (e: any) {
      setErr(e?.message || "Could not set status");
      setSaving(false);
      return;
    }
    setSaving(false);
    setFinishing(false);
    if (typeof window !== "undefined" && leadId) window.location.href = `/leads/${leadId}`;
  }

  async function save(advance = false) {
    setSaving(true); setErr(null);
    try {
      const properties = [];
      for (const p of props) {
        let canonical_id: string | undefined;
        if (p.resolved?.place_id) {
          try {
            const r = await fetch("/api/canonical", {
              method: "POST", headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ place_id: p.resolved.place_id, name: p.resolved.name, address: p.resolved.address,
                lat: p.resolved.lat, lng: p.resolved.lng, current_brand: p.resolved.current_brand, firm_id: firmId }),
            });
            const text = await r.text();
            const d = text ? JSON.parse(text) : {};
            if (r.ok) canonical_id = d.id;
          } catch {
            // Canonical resolution is best-effort; a hiccup here must not block the
            // whole save or leave a stuck error. Save the property without the id.
          }
        }
        properties.push({ ...cleanProp(p.values), canonical_id });
      }
      const r = await fetch("/api/claim-intake", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ claim_id: claimId, firm_id: firmId, answers: cleanAnswers(answers, claimType), properties }),
      });
      const text = await r.text();
      const d = text ? JSON.parse(text) : {};
      if (!r.ok) throw new Error(d.error || "save failed");
      setErr(null);
      setSavedAt(new Date().toLocaleTimeString());
      if (advance && step < steps.length - 1) setStep(step + 1);
    } catch (e: any) { setErr(e?.message || "save failed"); }
    setSaving(false);
  }

  return (
    <div className={`intake-shell ${locked ? "intake-locked" : ""}`}>
      <div className="intake-lockbar">
        {locked ? (
          <><span className="lock-note">🔒 Read-only. Click edit to make changes.</span><button className="btn gold sm" onClick={() => setLocked(false)}>✏️ Edit answers</button></>
        ) : (
          <><span className="lock-note editing">✏️ Editing, changes save automatically{savedAt ? ` · saved ${savedAt}` : ""}{saving ? " · saving…" : ""}</span>
          <label className="auto-adv-toggle" title="Automatically move to the next section when this one is complete"><input type="checkbox" checked={autoAdvance} onChange={(e) => setAutoAdvance(e.target.checked)} /> Auto-advance</label>
          <button className="btn ghost sm" onClick={() => setLocked(true)}>🔒 Done</button></>
        )}
        <span className="spacer" style={{ flex: 1 }} />
        <span className="intake-remaining" title={`${completion.answered} of ${completion.total} answered`} style={{
          display: "inline-flex", alignItems: "center", gap: 7, fontSize: 13, fontWeight: 700,
          padding: "4px 12px", borderRadius: 999, whiteSpace: "nowrap",
          background: completion.remaining === 0 ? "rgba(34,197,94,.12)" : "rgba(217,152,42,.12)",
          color: completion.remaining === 0 ? "#15803d" : "#a16207",
          border: `1px solid ${completion.remaining === 0 ? "rgba(34,197,94,.35)" : "rgba(217,152,42,.35)"}`,
        }}>
          {completion.remaining === 0
            ? <>✓ All {completion.total} answered</>
            : <>{completion.remaining} of {completion.total} left</>}
        </span>
      </div>
      <nav className="steprail">
        {steps.map((s, i) => (
          <button key={s.id}
            className={`${i === step ? "active" : ""} ${segAnswered(s.id) ? "done" : ""}`}
            onClick={() => setStep(i)}>
            <span className="stepnum">{segAnswered(s.id) ? "✓" : i + 1}</span>
            {cleanTitle(s.title)}
          </button>
        ))}
      </nav>

      {advanceBanner && (
        <div className="advance-banner">
          <span>✓ Section complete. Moving to the next section…</span>
          <button className="btn ghost sm" onClick={() => { if (advanceTimer.current) clearTimeout(advanceTimer.current); setAdvanceBanner(false); }}>Stay here</button>
        </div>
      )}

      <div>
        <div className="seg-head">
          <h2>{viewAll ? "Full intake" : cleanTitle(curStep.title)}</h2>
          {!viewAll && <span className="seg-count">Step {step + 1} of {steps.length}</span>}
          <div className="spacer" />
          <button className="btn ghost" onClick={() => setViewAll(!viewAll)}>
            {viewAll ? "Stepped view" : "View entire intake"}
          </button>
        </div>

        {viewAll ? (
          <div>
            {segments.map((seg) => (
              <div key={seg.id} style={{ marginBottom: 28 }}>
                <div className="section-title">{cleanTitle(seg.title)}</div>
                {isProps(seg.id) ? (
                  <>
                    {props.map((p, idx) => (
                      <PropertyCard key={p._key} index={idx} state={p} fields={propFields}
                        onResolve={(r) => resolveProp(p._key, r)}
                        onChange={(id, v) => setPropVal(p._key, id, v)}
                        onRemove={() => removeProperty(p._key)} />
                    ))}
                    <button className="btn secondary" onClick={addProperty}>+ Add another property</button>
                  </>
                ) : (
                  seg.fields.map((f) => {
                    if (!fieldVisible(f, answers)) return null;
                    if (f.kind === "script") {
                      return <FieldRenderer key={f.id} field={f} answers={answers} value={answers[f.id]} onChange={(v) => setVal(f.id, v)} feeds={autofillFeeds[f.id]} />;
                    }
                    if (f.kind === "gate") {
                      return (
                        <div key={f.id} className="qcard gate-wrap">
                            <FieldRenderer field={f} answers={answers} value={answers[f.id]} onChange={(v) => setVal(f.id, v)} qNum={qNum[f.id]} feeds={autofillFeeds[f.id]} />
                        </div>
                      );
                    }
                    const ans = answers[f.id] !== undefined && answers[f.id] !== null && answers[f.id] !== "";
                    return (
                      <div key={f.id} className={`qcard ${ans ? "answered" : ""} ${f.vital ? "vital-q" : ""}`}>
                        <FieldRenderer field={f} answers={answers} value={answers[f.id]} onChange={(v) => setVal(f.id, v)} onSetField={(id, v) => setVal(id, v)} qNum={qNum[f.id]} feeds={autofillFeeds[f.id]} />
                      </div>
                    );
                  })
                )}
              </div>
            ))}
            <div className="section-title">Schedule</div>
            <CalendlyEmbed name={claimantName} email={claimantEmail} />
            <div className="seg-nav">
              <div className="spacer" />
              {savedAt && <span className="muted">Saved {savedAt}</span>}
              {err && <span style={{ color: "var(--danger)" }}>{err}</span>}
              <button className="btn" disabled={saving} onClick={() => save(false)}>{saving ? "Saving…" : "Save claim"}</button>
            </div>
          </div>
        ) : isSchedule(curStep.id) ? (
          <>
            <p className="seg-sub">Book the case manager call with the claimant before you wrap up.</p>
            <CalendlyEmbed name={claimantName} email={claimantEmail} />
            <div style={{ marginTop: 14 }}>
              <label className="perm">
                <input type="checkbox" checked={scheduled} onChange={(e) => setScheduled(e.target.checked)} />
                {" "}Call has been scheduled (or callback arranged)
              </label>
            </div>
          </>
        ) : isProps(curStep.id) ? (
          <>
            <p className="seg-sub">Add one property per hotel/motel the claimant can identify.</p>
            {props.map((p, idx) => (
              <PropertyCard key={p._key} index={idx} state={p} fields={propFields}
                onResolve={(r) => resolveProp(p._key, r)}
                onChange={(id, v) => setPropVal(p._key, id, v)}
                onRemove={() => removeProperty(p._key)} />
            ))}
            <button className="btn secondary" onClick={addProperty}>+ Add another property</button>
          </>
        ) : (
          <>
            {(() => {
              const fields = curSegment?.fields ?? [];
              const SHORT = new Set(["text", "phone", "email", "date", "int", "select"]);
              const out: React.ReactNode[] = [];
              let bucket: typeof fields = [];
              const flush = (key: string) => {
                if (!bucket.length) return;
                out.push(
                  <div className="grid2" key={`g-${key}`}>
                    {bucket.map((f) => {
                      if (!fieldVisible(f, answers)) return null;
                      const answered = answers[f.id] !== undefined && answers[f.id] !== null && answers[f.id] !== "";
                      return (
                        <div key={f.id} className={`qcard ${answered ? "answered" : ""} ${f.vital ? "vital-q" : ""}`}>
                            <FieldRenderer field={f} answers={answers} value={answers[f.id]} onChange={(v) => setVal(f.id, v)} onSetField={(id, v) => setVal(id, v)} qNum={qNum[f.id]} feeds={autofillFeeds[f.id]} />
                        </div>
                      );
                    })}
                  </div>
                );
                bucket = [];
              };
              fields.forEach((f, i) => {
                if (f.kind === "script") {
                  flush(`b${i}`);
                  out.push(<FieldRenderer key={f.id} field={f} answers={answers} value={answers[f.id]} onChange={(v) => setVal(f.id, v)} feeds={autofillFeeds[f.id]} />);
                } else if (f.kind === "gate") {
                  flush(`b${i}`);
                  out.push(<FieldRenderer key={f.id} field={f} answers={answers} value={answers[f.id]} onChange={(v) => setVal(f.id, v)} qNum={qNum[f.id]} feeds={autofillFeeds[f.id]} />);
                } else if (SHORT.has(f.kind)) {
                  bucket.push(f);
                } else {
                  flush(`b${i}`);
                  const answered = answers[f.id] !== undefined && answers[f.id] !== null && answers[f.id] !== "";
                  out.push(
                    <div key={f.id} className={`qcard ${answered ? "answered" : ""} ${f.vital ? "vital-q" : ""}`}>
                      <FieldRenderer field={f} answers={answers} value={answers[f.id]} onChange={(v) => setVal(f.id, v)} onSetField={(id, v) => setVal(id, v)} qNum={qNum[f.id]} feeds={autofillFeeds[f.id]} />
                    </div>
                  );
                }
              });
              flush("end");
              return out;
            })()}
          </>
        )}

        {!viewAll && (
        <div className="seg-nav">
          <button className="btn ghost" disabled={step === 0} onClick={() => setStep(step - 1)}>← Back</button>
          <div className="spacer" />
          {savedAt && <span className="muted">Saved {savedAt}</span>}
          {err && <span style={{ color: "var(--danger)" }}>{err}</span>}
          <button className="btn ghost" disabled={saving} onClick={() => save(false)}>{saving ? "Saving…" : "Save"}</button>
          {step < steps.length - 1
            ? <button className="btn" disabled={saving} onClick={() => save(true)}>Save &amp; next →</button>
            : <button className="btn" disabled={saving} onClick={() => setFinishing(true)}>Finish &amp; set status</button>}
        </div>
        )}
      </div>

      {finishing && (
        <div className="modal-back" onClick={() => { setFinishing(false); setDqPick(false); }}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-h"><h3>Set claim status</h3><button className="btn ghost" style={{ marginLeft: "auto" }} onClick={() => { setFinishing(false); setDqPick(false); }}>Cancel</button></div>
            <div className="modal-b">
              <p className="muted" style={{ marginTop: 0 }}>How did this call end?</p>
              {!dqPick ? (
                <div className="outcome-grid">
                  <button className="outcome good" disabled={saving} onClick={() => finishWithStatus("signed_grievous")}>
                    <b>Signed the retainer</b><span>Client signed while on the call</span>
                  </button>
                  <button className="outcome good" disabled={saving} onClick={() => finishWithStatus("transferred")}>
                    <b>Live transferred to the firm</b><span>Firm picked up and took the caller</span>
                  </button>
                  <button className="outcome warn" disabled={saving} onClick={() => finishWithStatus("transfer_no_answer")}>
                    <b>Transfer, no answer</b><span>Qualified, firm did not pick up after 2 tries</span>
                  </button>
                  <button className="outcome warn" disabled={saving} onClick={() => finishWithStatus("esign_sent")}>
                    <b>e-Sign sent, not signed yet</b><span>Retainer is out, waiting on the client</span>
                  </button>
                  <button className="outcome info" disabled={saving} onClick={() => finishWithStatus("network_referred")}>
                    <b>Referred to the network</b><span>Outside this firm, sent to Lexamica</span>
                  </button>
                  <button className="outcome neutral" disabled={saving} onClick={() => finishWithStatus("contacting")}>
                    <b>Incomplete, call back</b><span>Did not finish the intake</span>
                  </button>
                  <button className="outcome bad" disabled={saving} onClick={() => setDqPick(true)}>
                    <b>Disqualified</b><span>Pick a reason on the next screen</span>
                  </button>
                </div>
              ) : (
                <div>
                  <div className="section-title" style={{ marginTop: 0 }}>Why is it disqualified?</div>
                  <div className="outcome-grid">
                    {dqReasons.map((r: any) => (
                      <button key={r.key} className="outcome bad" disabled={saving}
                        onClick={() => finishWithStatus("dq", r.key)}>
                        <b>{r.label}</b><span>{r.category}</span>
                      </button>
                    ))}
                  </div>
                  <button className="btn ghost" style={{ marginTop: 10 }} onClick={() => setDqPick(false)}>Back</button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function PropertyCard({ index, state, fields, onResolve, onChange, onRemove }: {
  index: number; state: PropertyState; fields: any[];
  onResolve: (r: ResolvedProperty) => void;
  onChange: (id: string, v: any) => void; onRemove: () => void;
}) {
  return (
    <div className="card" style={{ borderLeft: "4px solid var(--accent)" }}>
      <div className="row">
        <strong>Property {index + 1}</strong>
        {state.resolved && <span className="badge stage">{state.resolved.name}</span>}
        <div className="spacer" />
        <button className="btn ghost" onClick={onRemove}>Remove</button>
      </div>
      {!state.resolved && <PropertyLookup onResolved={onResolve} />}
      {state.resolved && fields.filter((f) => f.kind !== "property_lookup").map((f) => (
        <FieldRenderer key={f.id} field={f} answers={state.values} value={state.values[f.id]} onChange={(v) => onChange(f.id, v)} />
      ))}
    </div>
  );
}

function cleanTitle(t: string) { return t.replace(/\s*\(.*?\)\s*/g, "").trim(); }

function synthSet(claimType?: string) {
  // Sections and scripts never hold answers. Gates DO (they are numbered
  // Yes/No questions), so they save like any other field. Stripping them here
  // made "58/58 answered" reopen as "3 questions left" (Astra audit, Sep 27).
  return new Set(intakeForType(claimType ?? "motel_trafficking").filter((f) => ["section","script"].includes(f.kind)).map((f) => f.id));
}
function cleanAnswers(o: Record<string, any>, claimType?: string) {
  const SYNTH = synthSet(claimType);
  const out: Record<string, any> = {};
  for (const k of Object.keys(o)) if (!SYNTH.has(k)) out[k] = o[k];
  return out;
}
// Whitelist of writable claim_properties columns. This is intentionally a
// whitelist, not a blocklist: brand_mismatch is a GENERATED column (Postgres
// computes it from remembered_brand vs current_brand), so any attempt to write
// it fails the whole insert. Only these columns may be sent.
const WRITABLE_PROP_COLS = [
  "canonical_id", "sequence_order", "remembered_brand", "current_brand",
  "name_as_recalled", "address", "cross_streets", "city", "state",
  "place_id", "lat", "lng", "loc_confidence", "landmarks",
  "stay_month", "stay_year", "stay_duration", "room_floor", "age_at_time",
  "under_18", "acts_count_here", "who_booked_paid", "payment_method",
  "men_per_day", "asked_staff_for_help", "asked_whom", "police_emt_called",
  "repeatedly_same_motel", "specific_rooms_req", "room_change_freq",
  "visitors_check_desk", "men_waiting_areas", "housekeeping_entered",
  "towel_change_freq", "sheet_change_freq", "dnd_long_periods", "condoms_visible",
  "staff_interact_traffk", "staff_interact_victim", "mgmt_intervened",
  "violence_public_areas", "drug_paraphernalia", "staff_witnessed_drugs",
  "staff_knowledge_other", "has_variance", "variance_notes",
  "variance_trafficker", "variance_control",
] as const;

function cleanProp(o: Record<string, any>) {
  // Keep writable fixed columns AND unknown imported-form field ids (the server
  // routes unknowns into claim_properties.custom). Only strip display-only keys.
  const DROP = new Set(["name", "place_id_display", "resolved"]);
  const out: Record<string, any> = {};
  for (const k of Object.keys(o)) if (!DROP.has(k)) out[k] = o[k];
  return out;
}
