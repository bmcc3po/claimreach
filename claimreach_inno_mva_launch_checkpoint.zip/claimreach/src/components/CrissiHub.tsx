"use client";
import { useState, useMemo } from "react";
import { CrissiLogo } from "./CrissiLogo";
import { BIBLE, BIBLE_GROUPS, searchBible, type BibleEntry } from "@/lib/bible";
import { SILVER_LINERS, searchLiners } from "@/lib/silver-liners";
import { COURSE } from "@/lib/course";
import { CRISIS_SOP } from "@/lib/sop";
import { DISCLAIMER_SHORT, DISCLAIMER_FULL, HARD_LINES } from "@/lib/crissi-disclaimers";
import CrissiAcademy from "./CrissiAcademy";
import CampaignTraining from "./CampaignTraining";
import MethodPillar from "./MethodPillar";
import LearningPath from "./LearningPath";
import SilverLiners from "./SilverLiners";
import TrainingRecords from "./TrainingRecords";
import BibleReader from "./BibleReader";

type Chapter = "start" | "course" | "method" | "campaigns" | "bible" | "liners" | "sop" | "records";

const CHAPTERS: { id: Chapter; num: string; label: string; sub: string; icon: string }[] = [
  { id: "start", num: "00", label: "Start Here", sub: "What Crissi is & the boundaries", icon: "🧭" },
  { id: "course", num: "01", label: "The Course", sub: "9 guided chapters · your training path", icon: "🎓" },
  { id: "method", num: "02", label: "The Method", sub: "How we run every call · reframes · response drill", icon: "🧭" },
  { id: "campaigns", num: "03", label: "Campaigns", sub: "Case-specific criteria & certification", icon: "🎯" },
  { id: "bible", num: "04", label: "The Bible", sub: "Searchable reference for any moment", icon: "📖" },
  { id: "liners", num: "05", label: "Silver Liners", sub: "Hope lines to lift a chin", icon: "✨" },
  { id: "sop", num: "06", label: "Crisis SOP", sub: "The protocol", icon: "🆘" },
];

export default function CrissiHub({ isManager = false }: { isManager?: boolean }) {
  const [chapter, setChapter] = useState<Chapter>("start");
  const [globalSearch, setGlobalSearch] = useState("");

  // Panic-mode global search across Bible + Liners.
  const searchHits = useMemo(() => {
    const q = globalSearch.trim();
    if (!q) return null;
    return {
      bible: searchBible(q).slice(0, 8),
      liners: searchLiners(q).slice(0, 8),
    };
  }, [globalSearch]);

  const chapters = isManager
    ? [...CHAPTERS, { id: "records" as Chapter, num: "07", label: "Records", sub: "Who completed training", icon: "📋" }]
    : CHAPTERS;

  return (
    <div className="crissi-hub">
      {/* Left rail — chapters */}
      <aside className="crissi-rail">
        <div className="crissi-rail-head">
          <CrissiLogo height={30} />
        </div>
        <div className="crissi-rail-search">
          <input placeholder="🔍 Search everything…" value={globalSearch} onChange={(e) => setGlobalSearch(e.target.value)} />
        </div>
        {!globalSearch && chapters.map((c) => (
          <button key={c.id} className={`crissi-chapter ${chapter === c.id ? "active" : ""}`} onClick={() => setChapter(c.id)}>
            <span className="crissi-chapter-num">{c.num}</span>
            <span className="crissi-chapter-text">
              <span className="crissi-chapter-label">{c.icon} {c.label}</span>
              <span className="crissi-chapter-sub">{c.sub}</span>
            </span>
          </button>
        ))}
        {globalSearch && <p className="muted" style={{ fontSize: 12, padding: "8px 4px" }}>Searching across the Bible and Silver Liners. Clear to return to chapters.</p>}
      </aside>

      {/* Main panel */}
      <main className="crissi-main">
        {searchHits ? (
          <GlobalResults hits={searchHits} onClear={() => setGlobalSearch("")} onOpenBible={() => { setGlobalSearch(""); setChapter("bible"); }} />
        ) : (
          <>
            {chapter === "start" && <LearningPath onGo={setChapter} />}
            {chapter === "course" && <CrissiAcademy />}
            {chapter === "method" && (
              <div>
                <ChapterHead num="02" title="The Method" blurb="How we run every call, on every campaign. Frame, message, register, the ceiling, the Mirror Rule, the three Rs, the downshift, and the door. Read this before any campaign." />
                <MethodPillar />
              </div>
            )}
            {chapter === "campaigns" && (
              <div>
                <ChapterHead num="03" title="Campaigns" blurb="The case in front of you. Criteria, call order, technique, and a certification you pass before you take live calls on it." />
                <CampaignTraining />
              </div>
            )}
            {chapter === "bible" && <BibleReader />}
            {chapter === "liners" && (
              <div>
                <div className="card" style={{ padding: 16, marginBottom: 14, borderLeft: "4px solid var(--danger)" }}>
                  <strong style={{ color: "var(--danger)" }}>Scope: these are not interview tools.</strong>
                  <p style={{ fontSize: 13.5, margin: "6px 0 0" }}>
                    Nothing in this bank goes into the middle of a form. Some of these lines name strength or courage, which is a Ceiling violation during an intake. Use them at the close once the form is done, at the door when you've stopped the form entirely, or on a check-in call. Inside an interview, a hope line is a comment on how she's doing, which characterizes her. Outside one, the same words are a kindness.
                  </p>
                </div>
                <ChapterHead num="05" title="Silver Liners" blurb="Hopeful lines to get a caller through the call and the day. A bandage, not a fix. Search by the mood or moment." />
                <SilverLiners />
              </div>
            )}
            {chapter === "sop" && <SopChapter />}
            {chapter === "records" && isManager && (
              <div>
                <ChapterHead num="07" title="Training Records" blurb="Who has completed which Crissi Academy chapter, with quiz scores and dates." />
                <TrainingRecords />
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}

function ChapterHead({ num, title, blurb }: { num: string; title: string; blurb: string }) {
  return (
    <div className="chapter-head">
      <span className="chapter-head-num">{num}</span>
      <div>
        <h1 style={{ margin: 0 }}>{title}</h1>
        <p className="muted" style={{ margin: "2px 0 0" }}>{blurb}</p>
      </div>
    </div>
  );
}

function SopChapter() {
  return (
    <div>
      <ChapterHead num="06" title={CRISIS_SOP.title} blurb={CRISIS_SOP.subtitle} />
      <div className="disclaimer-bar" style={{ marginBottom: 16, maxWidth: 760 }}>{DISCLAIMER_FULL[0]} {DISCLAIMER_FULL[2]}</div>
      <p style={{ fontSize: 14, maxWidth: 760 }}>{CRISIS_SOP.intro}</p>
      <div className="sop-grid">
        {CRISIS_SOP.sections.map((s) => (
          <div key={s.h} className="card" style={{ padding: 16 }}>
            <div className="section-title">{s.h}</div>
            <ul className="bible-list" style={{ marginBottom: 0 }}>{s.items.map((it, i) => <li key={i}>{it}</li>)}</ul>
          </div>
        ))}
      </div>
      <div className="card" style={{ padding: 16, marginTop: 14, maxWidth: 760 }}>
        <div className="section-title">Key resources</div>
        {CRISIS_SOP.resources.map((r) => <div key={r.name} className="vrow"><span className="vk">{r.name}</span><span className="vv">{r.value}</span></div>)}
      </div>
    </div>
  );
}

function GlobalResults({ hits, onClear, onOpenBible }: { hits: { bible: BibleEntry[]; liners: any[] }; onClear: () => void; onOpenBible: () => void }) {
  return (
    <div>
      <div className="row" style={{ marginBottom: 12 }}>
        <h1 style={{ margin: 0 }}>Search results</h1>
        <button className="btn ghost sm" style={{ marginLeft: 12 }} onClick={onClear}>Clear</button>
      </div>

      {hits.bible.length > 0 && (
        <div style={{ marginBottom: 20 }}>
          <div className="section-title">📖 From the Bible</div>
          {hits.bible.map((e) => (
            <div key={e.id} className="card" style={{ padding: 14, marginBottom: 8 }}>
              <strong>{e.acute && "🚨 "}{e.title}</strong>
              <p className="muted" style={{ fontSize: 13, margin: "4px 0 0" }}>{e.summary}</p>
            </div>
          ))}
          <button className="btn ghost sm" onClick={onOpenBible}>Open the full Bible →</button>
        </div>
      )}

      {hits.liners.length > 0 && (
        <div>
          <div className="section-title">✨ Silver Liners</div>
          <div className="liner-grid">
            {hits.liners.map(({ group, liner }: any, i: number) => (
              <div key={i} className="liner-card">
                <div className="liner-line">{liner.framing && <span className="liner-framing">{liner.framing} </span>}"{liner.line}"</div>
                <div className="liner-when"><strong>When:</strong> {liner.when}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {hits.bible.length === 0 && hits.liners.length === 0 && <p className="muted">Nothing matched. Try a different word.</p>}
    </div>
  );
}
