export const runtime = "edge";
import { supabaseServer } from "@/lib/supabase-server";
import { authUser } from "@/lib/auth-user";
import { redirect } from "next/navigation";
import CampaignsManager from "@/components/CampaignsManager";

export default async function CampaignsSettingsPage() {
  const sb = await supabaseServer();
  const { data: { user } } = await authUser();
  const { data: me } = await sb.from("app_users").select("role").eq("id", user!.id).maybeSingle();
  if (!me || !["owner", "admin"].includes(me.role)) redirect("/settings");

  const { data: campaigns } = await sb.from("campaigns").select("*, firms(name)").order("name");
  const { data: firms } = await sb.from("firms").select("id, name").order("name");
  const { data: textTpls } = await sb.from("retainer_templates").select("id, name").order("name");
  const { data: pdfTpls } = await sb.from("pdf_templates").select("id, name").order("name");

  // Unified retainer options: text templates AND uploaded PDF templates, each
  // tagged by kind so a campaign can use either as its retainer / packet doc.
  const retainerTemplates = [
    ...(textTpls ?? []).map((t) => ({ id: t.id, name: t.name, kind: "text" as const })),
    ...(pdfTpls ?? []).map((t) => ({ id: t.id, name: `${t.name} (PDF)`, kind: "pdf" as const })),
  ];

  return (
    <div>
      <h2 style={{ marginTop: 0 }}>Campaigns</h2>
      <p className="muted" style={{ marginTop: 0, maxWidth: 720 }}>Each campaign is one firm running one case type. Add lead picks a campaign and inherits the firm, type, intake form, retainer, and billing.</p>
      <CampaignsManager initial={campaigns ?? []} firms={firms ?? []} retainerTemplates={retainerTemplates} />
    </div>
  );
}
