import { NextRequest, NextResponse } from "next/server";
import { supabaseServer, supabaseAdmin } from "@/lib/supabase-server";
import { newKeyPair } from "@/lib/webhooks";
export const runtime = "edge";

async function gate() {
  const sb = await supabaseServer();
  const { data: auth } = await sb.auth.getUser();
  if (!auth?.user) return null;
  const { data: me } = await sb.from("app_users").select("role, firm_id").eq("id", auth.user.id).maybeSingle();
  if (!me || !["owner", "admin"].includes(me.role)) return null;
  return { sb, me, uid: auth.user.id };
}

export async function GET() {
  const g = await gate();
  if (!g) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const admin = supabaseAdmin();
  const { data: keys } = await admin.from("api_keys").select("id, firm_id, label, key_id, scope, active, last_used_at, created_at").order("created_at", { ascending: false });
  const { data: endpoints } = await admin.from("webhook_endpoints").select("id, firm_id, url, events, active, created_at").order("created_at", { ascending: false });
  const { data: events } = await admin.from("webhook_events").select("id, firm_id, direction, event_type, status, http_status, created_at").order("created_at", { ascending: false }).limit(50);
  const { data: firms } = await admin.from("firms").select("id, name").order("name");
  return NextResponse.json({ keys: keys ?? [], endpoints: endpoints ?? [], events: events ?? [], firms: firms ?? [] });
}

export async function POST(req: NextRequest) {
  const g = await gate();
  if (!g) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const admin = supabaseAdmin();
  const b = await req.json();

  if (b.op === "create_key") {
    const scope = b.scope === "master" ? "master" : "firm";
    const { key_id, secret } = newKeyPair(scope);
    const { error } = await admin.from("api_keys").insert({
      firm_id: scope === "master" ? null : b.firm_id, label: b.label || "API key", key_id, secret, scope, created_by: g.uid,
    });
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    // secret shown ONCE here
    return NextResponse.json({ ok: true, key_id, secret });
  }
  if (b.op === "revoke_key") {
    await admin.from("api_keys").update({ active: false }).eq("id", b.id);
    return NextResponse.json({ ok: true });
  }
  if (b.op === "create_endpoint") {
    const secret = "whs_" + Array.from(crypto.getRandomValues(new Uint8Array(20))).map((x) => x.toString(16).padStart(2, "0")).join("");
    const { error } = await admin.from("webhook_endpoints").insert({
      firm_id: b.firm_id, url: b.url, secret, events: b.events ?? [], created_by: g.uid,
      name: b.name ?? null,
      // Null campaign = every campaign for this firm. Set = only that campaign,
      // so an MVA feed and a trafficking feed can send different shapes.
      campaign_id: b.campaign_id || null,
      field_map: b.field_map ?? {},
      include_answers: b.include_answers !== false,
    });
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ ok: true, secret });
  }
  // Editing the map is the whole point of having one, so it is savable without
  // deleting and re-adding the endpoint (which would rotate the secret and
  // silently break the receiver's signature check).
  if (b.op === "update_endpoint") {
    const patch: any = {};
    if (b.field_map !== undefined) patch.field_map = b.field_map ?? {};
    if (b.campaign_id !== undefined) patch.campaign_id = b.campaign_id || null;
    if (b.include_answers !== undefined) patch.include_answers = b.include_answers !== false;
    if (b.events !== undefined) patch.events = b.events ?? [];
    if (b.name !== undefined) patch.name = b.name ?? null;
    if (b.url !== undefined && b.url) patch.url = b.url;
    const { error } = await admin.from("webhook_endpoints").update(patch).eq("id", b.id);
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ ok: true });
  }
  if (b.op === "revoke_endpoint") {
    await admin.from("webhook_endpoints").update({ active: false }).eq("id", b.id);
    return NextResponse.json({ ok: true });
  }
  if (b.op === "save_mapping") {
    const { data: existing } = await admin.from("field_mappings").select("id").eq("firm_id", b.firm_id).eq("direction", b.direction || "inbound").maybeSingle();
    if (existing) await admin.from("field_mappings").update({ map: b.map ?? {}, transforms: b.transforms ?? {} }).eq("id", existing.id);
    else await admin.from("field_mappings").insert({ firm_id: b.firm_id, direction: b.direction || "inbound", map: b.map ?? {}, transforms: b.transforms ?? {} });
    return NextResponse.json({ ok: true });
  }
  if (b.op === "save_justcall") {
    // One row per firm scope: update the existing row if present, else insert.
    const scope = b.firm_id || null;
    const q = admin.from("justcall_accounts").select("id");
    const { data: existing } = scope
      ? await q.eq("firm_id", scope).limit(1).maybeSingle()
      : await q.is("firm_id", null).limit(1).maybeSingle();
    const fields = { label: b.label || "JustCall", api_key: b.api_key, api_secret: b.api_secret, justcall_number: b.justcall_number || null, active: true };
    if (existing) {
      const { error } = await admin.from("justcall_accounts").update(fields).eq("id", existing.id);
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    } else {
      const { error } = await admin.from("justcall_accounts").insert({ firm_id: scope, ...fields });
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    }
    return NextResponse.json({ ok: true });
  }
  if (b.op === "save_esign") {
    const scope = b.firm_id || null;
    const q = admin.from("esign_accounts").select("id");
    const { data: existing } = scope
      ? await q.eq("firm_id", scope).limit(1).maybeSingle()
      : await q.is("firm_id", null).limit(1).maybeSingle();
    const fields: any = { provider: "signwell", api_key: b.api_key, test_mode: b.test_mode !== false, active: true };
    if (b.webhook_secret !== undefined) fields.webhook_secret = b.webhook_secret || null;
    if (existing) {
      const { error } = await admin.from("esign_accounts").update(fields).eq("id", existing.id);
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    } else {
      const { error } = await admin.from("esign_accounts").insert({ firm_id: scope, ...fields });
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    }
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ error: "unknown op" }, { status: 400 });
}
