import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase-server";
import { lookupKey, verifySignature, mapInbound, canonicalToLeadColumns } from "@/lib/webhooks";
import { fireEvent } from "@/lib/webhook-deliver";
export const runtime = "edge";

// Inbound lead webhook. Any source POSTs a lead here.
// Header: X-CR-Key: <key_id>, X-CR-Signature: sha256=<hmac of raw body using the key secret>
export async function POST(req: NextRequest, { params }: { params: Promise<{ key_id: string }> }) {
  const { key_id } = await params;
  const raw = await req.text();
  const admin = supabaseAdmin();

  const key = await lookupKey(key_id);
  if (!key) { await log(admin, null, "inbound", "lead.in", "failed", 401, raw, "unknown key"); return NextResponse.json({ error: "unknown key" }, { status: 401 }); }

  const sig = req.headers.get("x-cr-signature");
  const ok = await verifySignature(key.secret, raw, sig);
  if (!ok) { await log(admin, key.firm_id, "inbound", "lead.in", "failed", 401, raw, "bad signature"); return NextResponse.json({ error: "bad signature" }, { status: 401 }); }

  let body: any;
  try { body = JSON.parse(raw); } catch { return NextResponse.json({ error: "invalid json" }, { status: 400 }); }

  // field mapping for this firm (inbound) -> canonical ids
  const { data: fm } = await admin.from("field_mappings").select("map, transforms").eq("firm_id", key.firm_id).eq("direction", "inbound").maybeSingle();
  const mapped = mapInbound(body, fm ?? undefined);
  const cols = canonicalToLeadColumns(mapped);

  const firmId = key.firm_id;
  // Every column canonicalToLeadColumns fills is a real leads column, and it
  // fills one for every writable standard field (contact, person, emergency
  // contact, incident, case summary), so whatever a sender may set is stored.
  // Blank values are left out so a column's default stands. Ids, status,
  // ownership and SSN never come from the sender.
  // leads has no `status` column. The pipeline lives in `stage`
  // (pipeline_stage enum), which already defaults to 'referral_received'.
  // Naming a phantom column made Postgres reject the whole insert.
  const insert: any = { firm_id: firmId, source_key: key_id };
  for (const [k, val] of Object.entries(cols)) if (val !== null && val !== undefined && val !== "") insert[k] = val;
  insert.case_type = cols.case_type ?? "motel_trafficking";
  // never write the generated full_name column
  delete (insert as any).full_name;

  // de-dupe: skip if we already have this external_id for this firm
  if (insert.external_id) {
    const { data: dupe } = await admin.from("leads").select("id").eq("firm_id", firmId).eq("external_id", insert.external_id).maybeSingle();
    if (dupe) { await log(admin, firmId, "inbound", "lead.in", "received", 200, raw, "duplicate external_id"); return NextResponse.json({ ok: true, lead_id: dupe.id, duplicate: true }); }
  }

  const { data: lead, error } = await admin.from("leads").insert(insert).select("id, lead_no").single();
  if (error) { await log(admin, firmId, "inbound", "lead.in", "failed", 500, raw, error.message); return NextResponse.json({ error: error.message }, { status: 500 }); }

  // create a default claim for the case type
  const { error: cErr } = await admin.from("claims").insert({ firm_id: firmId, lead_id: lead.id, claim_type: insert.case_type, campaign: insert.campaign ?? null, status: "new" });
  if (cErr) {
    await log(admin, firmId, "inbound", "lead.in", "failed", 500, raw, `claim: ${cErr.message}`);
    return NextResponse.json({ error: `The file was made but its claim was not: ${cErr.message}`, lead_id: lead.id, lead_no: lead.lead_no }, { status: 500 });
  }

  await admin.from("api_keys").update({ last_used_at: new Date().toISOString() }).eq("id", key.id);
  await log(admin, firmId, "inbound", "lead.in", "received", 200, raw, null);

  // fire outbound lead.created to any subscribed endpoints
  // claim any orphaned calls/SMS that arrived before this file existed
  try { const { reconcileUnmatched } = await import("@/lib/comms"); await reconcileUnmatched(lead.id, insert.phone, firmId); } catch {}

  await fireEvent(firmId, "lead.created", { lead_id: lead.id, lead_no: lead.lead_no, ...insert }, { campaignId: null, answers: null });

  return NextResponse.json({ ok: true, lead_id: lead.id, lead_no: lead.lead_no });
}

async function log(admin: any, firm_id: string | null, direction: string, event_type: string, status: string, http: number, payload: string, error: string | null) {
  try { await admin.from("webhook_events").insert({ firm_id, direction, event_type, status, http_status: http, payload: safe(payload), error }); } catch {}
}
function safe(s: string) { try { return JSON.parse(s); } catch { return { raw: s.slice(0, 500) }; } }
