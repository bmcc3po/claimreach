"use client";
import { useState, useEffect } from "react";
import type { Field, FieldKind, ShowIf, Condition } from "@/lib/questionnaire";
import { fieldVisible } from "@/lib/questionnaire";
import { TEMPLATES } from "@/lib/form-templates";
import { canDeleteField, canHideField, canReorder, type TemplateField } from "@/lib/template-engine";
import FieldRenderer from "./FieldRenderer";

// Every kind the renderer can draw. If a kind is missing from this list, a
// question using it cannot be created here AND cannot be set back after someone
// changes its type, which is how the SSN and address fields would have quietly
// degraded into plain text boxes the first time anyone edited them.
const KINDS: { kind: FieldKind; label: string }[] = [
  { kind: "section", label: "Section" }, { kind: "script", label: "Script" },
  { kind: "text", label: "Short text" }, { kind: "longtext", label: "Long text" },
  { kind: "bool", label: "Yes / No" }, { kind: "select", label: "Dropdown" },
  { kind: "multiselect", label: "Checkboxes" }, { kind: "int", label: "Number" },
  { kind: "date", label: "Date" }, { kind: "time", label: "Time" },
  { kind: "monthyear", label: "Month/Year" },
  { kind: "phone", label: "Phone" }, { kind: "email", label: "Email" },
  // Address is a Google-backed lookup, not three text boxes the agent has to
  // spell the same way twice. SSN is masked, because an SSN in a plain text box
  // ends up in exports, logs and screenshots in the clear.
  { kind: "address", label: "Address (lookup)" }, { kind: "ssn", label: "SSN (masked)" },
  { kind: "facility_lookup", label: "Facility (verify)" }, { kind: "property_lookup", label: "Property (verify)" },
  { kind: "gate", label: "Gate (DQ)" },
];
const KIND_LABEL: Record<string, string> = Object.fromEntries(KINDS.map((k) => [k.kind, k.label]));

function blankField(kind: FieldKind): Field {
  const id = `f_${Math.random().toString(36).slice(2, 8)}`;
  const base: Field = { id, scope: "lead", kind, label: kind === "section" ? "New section" : "New question" };
  if (kind === "script") base.script = "Read this verbatim…";
  if (kind === "gate") base.gateType = "dq";
  if (kind === "select" || kind === "multiselect") base.options = ["Option 1", "Option 2"];
  return base;
}

export default function FormBuilder({ formId }: { formId?: string }) {
  const [name, setName] = useState("");
  const [role, setRole] = useState<string>("agent");
  const [uid, setUid] = useState<string>("");
  const [claimType, setClaimType] = useState("");
  const [description, setDescription] = useState("");
  const [fields, setFields] = useState<Field[]>([]);
  const [id, setId] = useState<string | undefined>(formId);
  const [status, setStatus] = useState("draft");
  const [sel, setSel] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [showPreview, setShowPreview] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [claimTypes, setClaimTypes] = useState<any[]>([]);
  // Which campaign owns this form. Blank means it is the shared master for the
  // case type, which is what every existing form is.
  const [campaignId, setCampaignId] = useState<string>("");
  const [campaignList, setCampaignList] = useState<any[]>([]);
  useEffect(() => {
    (async () => {
      try {
        const d = await (await fetch("/api/claim-types")).json();
        setClaimTypes(d.types ?? []);
      } catch {}
      try {
        const c = await (await fetch("/api/campaigns")).json();
        setCampaignList(c.campaigns ?? c ?? []);
      } catch {}
    })();
  }, []);
  const [aiDesc, setAiDesc] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [saved, setSaved] = useState<any[]>([]);

  useEffect(() => { if (formId) (async () => {
    const r = await fetch("/api/forms"); const d = await r.json();
    const f = (d.forms ?? []).find((x: any) => x.id === formId);
    if (f) { setName(f.name); setClaimType(f.claim_type); setDescription(f.description ?? ""); setFields(f.fields ?? []); setId(f.id); setStatus(f.status); setCampaignId(f.campaign_id ?? ""); }
  })(); }, [formId]);

  useEffect(() => { (async () => {
    try { const r = await fetch("/api/saved-questions"); const d = await r.json(); setSaved(d.questions ?? []); } catch {}
    try { const r = await fetch("/api/me"); const d = await r.json(); if (d.role) setRole(d.role); if (d.id) setUid(d.id); } catch {}
  })(); }, []);

  function addField(kind: FieldKind) {
    const f = { ...blankField(kind), origin: "custom", added_by: uid } as TemplateField;
    setFields((arr) => { const next = [...arr, f]; setSel(next.length - 1); return next; });
  }
  function update(i: number, patch: Partial<Field>) { setFields((arr) => arr.map((f, idx) => idx === i ? { ...f, ...patch } : f)); }
  function move(i: number, dir: -1 | 1) {
    if (!canReorder(role)) return;
    setFields((arr) => {
      const j = i + dir;
      if (j < 0 || j >= arr.length) return arr;
      const next = [...arr]; [next[i], next[j]] = [next[j], next[i]]; return next;
    });
  }
  function remove(i: number) {
    const f = fields[i] as TemplateField;
    if (!canDeleteField(role, f, uid)) {
      if (f.mandatoryGate) { alert("This is a mandatory gate and cannot be removed."); return; }
      if (f.locked || f.origin === "spine") {
        if (canHideField(role, f)) { hideField(i); return; }
        alert("Spine fields can only be deleted by the owner. You can hide optional ones."); return;
      }
      alert("You can only delete fields you added."); return;
    }
    setFields((arr) => arr.filter((_, idx) => idx !== i)); setSel(null);
  }
  function hideField(i: number) {
    setFields((arr) => arr.map((f, idx) => idx === i ? { ...f, hidden: !(f as TemplateField).hidden } : f));
  }

  function loadTemplate(tid: string) {
    const t = TEMPLATES.find((x) => x.id === tid); if (!t) return;
    // clone with fresh ids? keep ids (they're referenced by showIf) — only clone if collision
    setFields((arr) => [...arr, ...t.fields.map((f) => ({ ...f }))]);
    setMsg(`Added "${t.name}" (${t.fields.length} fields).`);
  }

  async function aiBuild(mode: "form" | "questions") {
    if (!aiDesc.trim()) return;
    setAiBusy(true); setMsg("Building… this can take up to a minute.");
    const existingLabels = fields.filter((f) => f.kind === "section").map((f) => f.label).join(", ");

    // One call attempt with its own abort window.
    async function attempt(): Promise<any> {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 110000); // align above the server's wall
      try {
        const r = await fetch("/api/forms/ai", { method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ mode, description: aiDesc, existingLabels }), signal: ctrl.signal });
        clearTimeout(timer);
        return await r.json();
      } finally { clearTimeout(timer); }
    }

    try {
      let d: any = null;
      try { d = await attempt(); } catch { d = null; }
      // Slow first gens often succeed on a second try; retry once automatically.
      if (!d || !d.fields || !d.fields.length) {
        if (d?.error) setMsg("First attempt was slow. Retrying once…");
        try { d = await attempt(); } catch { d = null; }
      }
      if (d && d.fields && d.fields.length) {
        if (mode === "form") {
          const starter = TEMPLATES.find((t) => t.id === "common")?.fields ?? [];
          const closeIdx = starter.findIndex((f) => f.id === "s_close");
          const head = closeIdx >= 0 ? starter.slice(0, closeIdx) : starter;
          const tail = closeIdx >= 0 ? starter.slice(closeIdx) : [];
          setFields([...head.map((f) => ({ ...f })), ...d.fields, ...tail.map((f) => ({ ...f }))]);
        } else {
          setFields((arr) => [...arr, ...d.fields]);
        }
        setAiOpen(false); setAiDesc("");
        setMsg(`AI added ${d.fields.length} campaign fields${mode === "form" ? " (plus the common opening, contact, and close)" : ""}. Review and edit.`);
      } else {
        setMsg(d?.error
          ? `${d.error} You can also use 'Just add these questions' to build it in smaller chunks.`
          : "AI returned nothing. Try rephrasing or shortening the description.");
      }
    } catch (e: any) {
      setMsg(e?.name === "AbortError"
        ? "The AI service ran long twice. Try a shorter description, or 'Just add these questions' for smaller chunks."
        : "Request failed. Check the AI connection (the relay) and try again.");
    } finally {
      setAiBusy(false);
    }
  }

  async function saveQuestion(f: Field) {
    const r = await fetch("/api/saved-questions", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ label: f.label, field: f, tags: [f.kind] }) });
    if (r.ok) { const d = await r.json(); setSaved((s) => [d.question, ...s]); setMsg("Saved to your question library."); }
  }
  function insertSaved(q: any) {
    const f = { ...q.field, id: `f_${Math.random().toString(36).slice(2, 8)}` };
    setFields((arr) => { const next = [...arr, f]; setSel(next.length - 1); return next; });
  }

  // Copy this form and bind the copy to one campaign, leaving the original
  // exactly where it was.
  //
  // Without this, the only way to give a second firm its own version was to
  // change the campaign dropdown on the existing form and save, which UPDATES
  // that row: the shared master would silently become one campaign's private
  // form and every other campaign of that case type would fall back to the
  // built-in code questions. Nothing would error. The other firm's agents would
  // just start reading a different questionnaire.
  async function copyToCampaign(targetCampaignId: string) {
    const target = campaignList.find((c: any) => c.id === targetCampaignId);
    if (!target) return;
    setSaving(true); setMsg("");
    try {
      const r = await fetch("/api/forms", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          op: "save",                      // no id, so this inserts a new row
          claim_type: claimType.trim().toLowerCase(),
          name: `${target.name} intake`,
          description: `Copy of ${name}, used only by ${target.name}.`,
          fields, campaign_id: targetCampaignId,
        }),
      });
      const d = await r.json();
      if (!r.ok) { setMsg(`Copy failed: ${d.error || r.status}`); setSaving(false); return; }
      setMsg(`Copied to ${target.name}. It is a draft, publish it when the questions are right.`);
      setTimeout(() => { window.location.href = `/forms/${d.id}`; }, 900);
    } catch (e: any) { setMsg(`Copy failed: ${String(e?.message ?? e)}`); }
    setSaving(false);
  }

  async function save(publish = false) {
    // Don't silently bail — tell the user exactly what's missing, loudly.
    if (!name.trim()) { setMsg("⚠ Add a Form name (top-left box) before saving."); window.scrollTo({ top: 0, behavior: "smooth" }); return; }
    if (!claimType.trim()) { setMsg("⚠ Add a Claim type key (top box, e.g. 'bard' or 'pressure_cooker') before saving."); window.scrollTo({ top: 0, behavior: "smooth" }); return; }
    if (fields.length === 0) { setMsg("⚠ Add at least one field before saving."); return; }
    setSaving(true); setMsg("Saving…");
    try {
      const r = await fetch("/api/forms", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ op: "save", id, claim_type: claimType.trim().toLowerCase(), name, description, fields, campaign_id: campaignId || null }) });
      const d = await r.json();
      if (!r.ok) { setMsg(`⚠ Save failed: ${d.error || r.status}. Your form is still here — nothing lost.`); setSaving(false); return; }
      setId(d.id);
      if (publish) {
        const pr = await fetch("/api/forms", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ op: "publish", id: d.id }) });
        if (!pr.ok) { const pd = await pr.json(); setMsg(`Saved as draft, but publish failed: ${pd.error || pr.status}. Try Publish again.`); setStatus("draft"); setSaving(false); return; }
        setStatus("published");
        setMsg("✓ Published and saved. Redirecting to the saved form…");
        setSaving(false);
        // Land on the saved form's edit page so it's provably persisted.
        setTimeout(() => { window.location.href = `/forms/${d.id}`; }, 600);
        return;
      }
      setMsg("✓ Saved as draft.");
    } catch (e: any) {
      setMsg(`⚠ Save error: ${String(e?.message ?? e)}. Your form is still here.`);
    }
    setSaving(false);
  }

  const selField = sel != null ? fields[sel] : null;
  // fields BEFORE the selected one — valid targets for a condition
  const earlierAnswerFields = sel != null ? fields.slice(0, sel).filter((f) => !["section", "script", "gate"].includes(f.kind)) : [];

  if (showPreview) {
    return (
      <div>
        <button className="btn ghost sm" onClick={() => setShowPreview(false)}>← Back to builder</button>
        <div className="card" style={{ padding: 22, marginTop: 12 }}>
          <h2 style={{ marginTop: 0 }}>{name || "Untitled form"}</h2>
          {description && <p className="muted">{description}</p>}
          <FormPreview fields={fields} />
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="row" style={{ flexWrap: "wrap", gap: 10, marginBottom: 10 }}>
        <input placeholder="Form name (e.g. Bard PowerPort Intake)" value={name} onChange={(e) => setName(e.target.value)} style={{ flex: 1, minWidth: 200 }} />
        <input placeholder="Claim type key" list="claimtypes" value={claimType} onChange={(e) => setClaimType(e.target.value)} style={{ width: 180 }} />
        {/* Read from the case type registry, not a list in this file. The
            hardcoded version had gone stale: it offered pressure_cooker and
            social_media, which have no campaigns, and omitted mva and prem,
            which are the two actually being run. Typing a key that is not a real
            case type creates a form nothing will ever resolve to. */}
        <datalist id="claimtypes">
          {claimTypes.map((t: any) => (
            <option key={t.key} value={t.key}>{t.label ?? t.key}</option>
          ))}
        </datalist>
        <select value={campaignId} onChange={(e) => setCampaignId(e.target.value)} style={{ width: "auto" }}
                title="Bind this form to one campaign, or leave it shared across every campaign of this case type.">
          <option value="">Shared, every campaign of this type</option>
          {campaignList
            .filter((c: any) => !claimType || c.case_type === claimType.trim().toLowerCase())
            .map((c: any) => <option key={c.id} value={c.id}>Only {c.name}</option>)}
        </select>
        {id && campaignList.filter((c: any) => c.case_type === claimType.trim().toLowerCase() && c.id !== campaignId).length > 0 && (
          <select className="sm" style={{ width: "auto" }} defaultValue="" disabled={saving}
                  onChange={(e) => { if (e.target.value) { copyToCampaign(e.target.value); e.target.value = ""; } }}>
            <option value="">Copy for another campaign...</option>
            {campaignList
              .filter((c: any) => c.case_type === claimType.trim().toLowerCase() && c.id !== campaignId)
              .map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        )}
        {status === "published" ? <span className="badge signed">Published</span> : <span className="badge count">Draft</span>}
      </div>
      {campaignId && (
        <p className="muted" style={{ fontSize: 12, marginTop: 0 }}>
          This form is used only by that campaign. Every other campaign of the same case type keeps the shared version.
        </p>
      )}
      <input placeholder="Description (optional)" value={description} onChange={(e) => setDescription(e.target.value)} style={{ marginBottom: 12 }} />

      {/* Top toolbar: AI + templates */}
      <div className="builder-toolbar">
        <button className="btn gold sm" onClick={() => setAiOpen((v) => !v)}>✨ Let AI build this form</button>
        <select className="sm" style={{ width: "auto" }} defaultValue="" onChange={(e) => { if (e.target.value) { loadTemplate(e.target.value); e.target.value = ""; } }}>
          <option value="">+ Start from template…</option>
          {TEMPLATES.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
        {saved.length > 0 && (
          <select className="sm" style={{ width: "auto" }} defaultValue="" onChange={(e) => { const q = saved.find((x) => x.id === e.target.value); if (q) { insertSaved(q); e.target.value = ""; } }}>
            <option value="">+ Insert saved question…</option>
            {saved.map((q) => <option key={q.id} value={q.id}>{q.label}</option>)}
          </select>
        )}
      </div>

      {aiOpen && (
        <div className="card" style={{ padding: 14, marginBottom: 12, borderColor: "var(--accent)" }}>
          <div className="section-title">✨ Describe the intake, AI drafts it</div>
          <textarea rows={3} placeholder="e.g. PFAS water contamination. 12 qualifying diagnoses (kidney cancer, testicular cancer, ulcerative colitis, thyroid disease…), diagnosed 1995 or later. 3 DQ gates: currently represented, signed with another firm, prior CL/PFAS signup. Capture diagnosis, diagnosis date, exposure location/duration." value={aiDesc} onChange={(e) => setAiDesc(e.target.value)} />
          <div className="row" style={{ gap: 8, marginTop: 8 }}>
            <button className="btn" onClick={() => aiBuild("form")} disabled={aiBusy}>{aiBusy ? "Building…" : "Build full form"}</button>
            <button className="btn ghost" onClick={() => aiBuild("questions")} disabled={aiBusy}>Just add these questions</button>
            <span className="muted" style={{ fontSize: 12, alignSelf: "center" }}>Review everything AI generates before publishing.</span>
          </div>
        </div>
      )}

      <div className="builder">
        <div className="builder-list">
          <div className="section-title">Fields</div>
          {fields.length === 0 && <p className="muted" style={{ fontSize: 13 }}>Add fields from the right, start from a template, or let AI build it.</p>}
          {fields.map((f, i) => {
            const tf = f as TemplateField;
            const locked = tf.locked || tf.origin === "spine";
            return (
            <div key={f.id} className={`builder-row ${sel === i ? "active" : ""} ${f.kind === "section" ? "is-section" : ""} ${tf.hidden ? "is-hidden" : ""}`} onClick={() => setSel(i)}>
              <span className="builder-kind">{f.kind === "section" ? "§" : f.kind === "gate" ? "⛔" : f.kind === "script" ? "📢" : "•"}</span>
              <span className="builder-label">
                {tf.mandatoryGate && <span className="lock-tag mand" title="Mandatory gate — cannot be removed">★</span>}
                {locked && !tf.mandatoryGate && <span className="lock-tag" title="Canonical spine — owner-only delete">🔒</span>}
                {f.label || "(untitled)"}
                {tf.hidden && <span className="badge dq" style={{ marginLeft: 6, fontSize: 9 }}>hidden</span>}
                {f.showIf && f.showIf.rules.length > 0 && <span className="badge stage" style={{ marginLeft: 6, fontSize: 9 }}>conditional</span>}
              </span>
              {f.kind !== "section" && <span className="builder-type">{KIND_LABEL[f.kind] ?? f.kind}</span>}
              <span className="builder-tools" onClick={(e) => e.stopPropagation()}>
                <button className="btn ghost sm" onClick={() => move(i, -1)} disabled={!canReorder(role)}>↑</button>
                <button className="btn ghost sm" onClick={() => move(i, 1)} disabled={!canReorder(role)}>↓</button>
                {tf.mandatoryGate ? <span className="lock-x" title="Locked">🔒</span>
                  : canDeleteField(role, tf, uid) ? <button className="btn ghost sm" onClick={() => remove(i)}>✕</button>
                  : canHideField(role, tf) ? <button className="btn ghost sm" onClick={() => hideField(i)} title="Hide (owner-only delete)">{tf.hidden ? "👁" : "🚫"}</button>
                  : <span className="lock-x" title="Owner-only">🔒</span>}
              </span>
            </div>
            );
          })}
        </div>

        <div className="builder-inspect">
          <div className="section-title">Add field</div>
          <div className="builder-kinds">{KINDS.map((k) => <button key={k.kind} className="chip" onClick={() => addField(k.kind)}>{k.label}</button>)}</div>

          {selField && (
            <div className="card" style={{ padding: 14, marginTop: 14 }}>
              <div className="row"><div className="section-title" style={{ margin: 0 }}>Edit field</div><span className="spacer" /><button className="btn ghost sm" onClick={() => saveQuestion(selField)}>★ Save to library</button></div>
              <label className="fld-label">Label</label>
              <input value={selField.label} onChange={(e) => update(sel!, { label: e.target.value })} />

              {selField.kind === "script" && (<><label className="fld-label">Script (verbatim)</label><textarea rows={3} value={selField.script ?? ""} onChange={(e) => update(sel!, { script: e.target.value })} /></>)}
              {(selField.kind === "select" || selField.kind === "multiselect") && (<><label className="fld-label">Options (one per line)</label><textarea rows={4} value={(selField.options ?? []).join("\n")} onChange={(e) => update(sel!, { options: e.target.value.split("\n").filter(Boolean) })} /></>)}
              {selField.kind === "gate" && (<><label className="fld-label">Gate type</label><select value={selField.gateType ?? "dq"} onChange={(e) => update(sel!, { gateType: e.target.value as any })}><option value="dq">DQ</option><option value="safety">Safety</option><option value="supervisor">Supervisor</option><option value="end_intake">End intake</option></select></>)}
              {selField.kind === "facility_lookup" && (<><label className="fld-label">Paired city/state field id</label><input value={selField.locField ?? ""} onChange={(e) => update(sel!, { locField: e.target.value })} placeholder="e.g. facility1_loc" /></>)}
              {selField.kind !== "section" && selField.kind !== "script" && (<>
                <label className="fld-label">Scope</label>
                <select value={selField.scope} onChange={(e) => update(sel!, { scope: e.target.value as any })}><option value="lead">Once per claimant</option><option value="property">Repeats per property/item</option></select>
                <label className="fld-row"><input type="checkbox" checked={!!selField.vital} onChange={(e) => update(sel!, { vital: e.target.checked })} /> Vital field</label>
                <label className="fld-label">Agent note (not read aloud)</label>
                <input value={selField.agentNote ?? ""} onChange={(e) => update(sel!, { agentNote: e.target.value })} />
              </>)}

              {/* CONDITIONAL LOGIC — easy builder */}
              <ConditionEditor field={selField} earlier={earlierAnswerFields} onChange={(showIf) => update(sel!, { showIf })} />

              <div className="fld-label" style={{ color: "var(--ink-faint)" }}>id: <code>{selField.id}</code></div>
            </div>
          )}
        </div>
      </div>

      <div className="row" style={{ gap: 8, marginTop: 16 }}>
        <button className="btn" onClick={() => save(false)} disabled={saving}>{saving ? "Saving…" : "Save draft"}</button>
        <button className="btn gold" onClick={() => save(true)} disabled={saving}>Save & publish</button>
        <button className="btn ghost" onClick={() => setShowPreview(true)} disabled={fields.length === 0}>Preview</button>
        {msg && <span className={`save-msg ${msg.startsWith("⚠") ? "warn" : msg.startsWith("✓") ? "ok" : ""}`}>{msg}</span>}
      </div>
    </div>
  );
}

// Easy conditional editor: "Only show this if [match] of these are true" + add rules.
function ConditionEditor({ field, earlier, onChange }: { field: Field; earlier: Field[]; onChange: (s?: ShowIf) => void }) {
  const si = field.showIf;
  const rules = si?.rules ?? [];
  function setRules(next: Condition[]) { onChange(next.length ? { match: si?.match ?? "all", rules: next } : undefined); }
  function setMatch(m: "all" | "any") { onChange({ match: m, rules }); }

  if (earlier.length === 0) return <div className="cond-note muted">Add answerable questions above this one to make it conditional.</div>;

  return (
    <div className="cond-box">
      <div className="fld-label">Only show this field if</div>
      {rules.length === 0 && <button className="btn ghost sm" onClick={() => setRules([{ fieldId: earlier[0].id, op: "is", value: "" }])}>+ Add a condition</button>}
      {rules.length > 0 && (
        <>
          <div className="row" style={{ gap: 6, marginBottom: 6 }}>
            <select className="sm" style={{ width: "auto" }} value={si?.match ?? "all"} onChange={(e) => setMatch(e.target.value as any)}>
              <option value="all">ALL of these (AND)</option>
              <option value="any">ANY of these (OR)</option>
            </select>
            <span className="muted" style={{ fontSize: 12, alignSelf: "center" }}>are true:</span>
          </div>
          {rules.map((r, i) => {
            const target = earlier.find((f) => f.id === r.fieldId);
            const opts = target?.options ?? (target?.kind === "bool" ? ["true", "false"] : []);
            return (
              <div key={i} className="cond-rule">
                <select className="sm" value={r.fieldId} onChange={(e) => { const n = [...rules]; n[i] = { ...r, fieldId: e.target.value }; setRules(n); }}>
                  {earlier.map((f) => <option key={f.id} value={f.id}>{f.label}</option>)}
                </select>
                <select className="sm" value={r.op} onChange={(e) => { const n = [...rules]; n[i] = { ...r, op: e.target.value as any }; setRules(n); }}>
                  <option value="is">is</option><option value="is_not">is not</option>
                  <option value="any_of">is any of</option><option value="not_blank">is answered</option><option value="is_blank">is blank</option>
                  {r.op === "date_bucket" && <option value="date_bucket">is in the intake date window</option>}
                </select>
                {(r.op === "is" || r.op === "is_not") && (
                  opts.length ? <select className="sm" value={r.value ?? ""} onChange={(e) => { const n = [...rules]; n[i] = { ...r, value: e.target.value }; setRules(n); }}><option value="">—</option>{opts.map((o) => <option key={o} value={o}>{o}</option>)}</select>
                  : <input className="sm" placeholder="value" value={r.value ?? ""} onChange={(e) => { const n = [...rules]; n[i] = { ...r, value: e.target.value }; setRules(n); }} />
                )}
                {r.op === "date_bucket" && <select className="sm" value={r.value ?? ""} onChange={(e) => { const n = [...rules]; n[i] = { ...r, value: e.target.value }; setRules(n); }}><option value="">Choose a window</option><option value="le30">30 days or less</option><option value="mid">More than 30, under 274 days</option><option value="old">274 days or more</option></select>}
                <button className="btn ghost sm" onClick={() => setRules(rules.filter((_, idx) => idx !== i))}>✕</button>
              </div>
            );
          })}
          <button className="btn ghost sm" onClick={() => setRules([...rules, { fieldId: earlier[0].id, op: "is", value: "" }])}>+ Add condition</button>
        </>
      )}
    </div>
  );
}

function FormPreview({ fields }: { fields: Field[] }) {
  const [vals, setVals] = useState<Record<string, any>>({});
  return (
    <div>
      {fields.map((f) => {
        if (!fieldVisible(f, vals)) return null;
        if (f.kind === "section") return <div key={f.id} className="section-title" style={{ fontSize: 15, marginTop: 18 }}>{f.label}</div>;
        if (f.kind === "script") return <div key={f.id} className="script" style={{ margin: "8px 0" }}>{f.script}</div>;
        if (f.kind === "gate") return <div key={f.id} className="gate" style={{ margin: "8px 0" }}>⛔ {f.label} <span className="muted">({f.gateType})</span></div>;
        return (
          <div key={f.id} className="field" style={{ marginBottom: 12 }}>
            <label className="fld-label">{f.label}{f.vital && <span className="badge gold" style={{ marginLeft: 6, fontSize: 10 }}>vital</span>}</label>
            <FieldRenderer field={f} value={vals[f.id]} onChange={(v) => setVals((s) => ({ ...s, [f.id]: v }))} onSetField={(id, v) => setVals((s) => ({ ...s, [id]: v }))} />
            {f.agentNote && <div className="muted" style={{ fontSize: 12 }}>{f.agentNote}</div>}
          </div>
        );
      })}
      {fields.length === 0 && <p className="muted">No fields yet.</p>}
    </div>
  );
}
