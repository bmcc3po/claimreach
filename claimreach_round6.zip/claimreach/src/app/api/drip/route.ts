import { NextRequest, NextResponse } from "next/server";
import { supabaseServer, supabaseAdmin } from "@/lib/supabase-server";
import {
  M6_DRIP_CAMPAIGN, collectDripCampaignKeys, dripCampaignClause, dripStepKey, sortDripRules,
} from "@/lib/drip-rules";
export const runtime = "edge";

const RULE_COLS = "id, name, channel, every_days, template, assign_to, active, campaign, stage, step_key, delay_days, subject, kind, method_note, fire_once";

// GET — list due drips (what would fire now) plus rules. ?campaign=motel6
// filters the rule table so Motel 6 is not mixed with unscoped TMT/prison rows.
export async function GET(req: NextRequest) {
  const sb = await supabaseServer();
  const { data: auth } = await sb.auth.getUser();
  if (!auth?.user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { data } = await sb.from("drips_due").select("*").limit(200);

  const allQ = await sb.from("drip_rules").select("campaign");
  const campaignKeys = collectDripCampaignKeys(allQ.data ?? []);

  const clause = dripCampaignClause(new URL(req.url).searchParams.get("campaign"));
  let q = sb.from("drip_rules").select(RULE_COLS);
  if (clause.kind === "none") q = q.is("campaign", null);
  if (clause.kind === "eq") q = q.eq("campaign", clause.value);
  const { data: rules, error } = await q.order("every_days");
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ due: data ?? [], rules: sortDripRules(rules ?? []), campaign_keys: campaignKeys });
}

// POST { op:'enroll', lead_id } — enroll a lead in active drip rules.
// POST { op:'process' } — fire all due drips (text/email), advance next_due.
export async function POST(req: NextRequest) {
  const sb = await supabaseServer();
  const { data: auth } = await sb.auth.getUser();
  if (!auth?.user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { data: me } = await sb.from("app_users").select("role, firm_id").eq("id", auth.user.id).maybeSingle();
  if (!me || me.role === "firm") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const p = await req.json();

  // ---- Manage drip RULES (owner/admin). create / update / toggle / delete ----
  if (["save_rule", "toggle_rule", "delete_rule"].includes(p.op)) {
    if (!["owner", "admin"].includes(me.role)) return NextResponse.json({ error: "forbidden" }, { status: 403 });
    const admin = supabaseAdmin();
    if (p.op === "delete_rule") {
      const { error } = await admin.from("drip_rules").delete().eq("id", p.id);
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
      return NextResponse.json({ ok: true });
    }
    if (p.op === "toggle_rule") {
      const { error } = await admin.from("drip_rules").update({ active: !!p.active }).eq("id", p.id);
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
      return NextResponse.json({ ok: true });
    }
    // save_rule (create or update)
    const name = (p.name || "").trim();
    const every = parseInt(p.every_days, 10);
    if (!name) return NextResponse.json({ error: "Name is required." }, { status: 200 });
    if (!every || every < 1) return NextResponse.json({ error: "Cadence (every N days) must be a positive number." }, { status: 200 });
    const channel = ["sms", "email", "call_reminder"].includes(p.channel) ? p.channel : "sms";
    const assign = ["agent", "case_manager", "both"].includes(p.assign_to) ? p.assign_to : "agent";
    const row: Record<string, any> = {
      name, channel, every_days: every, template: p.template ?? null,
      assign_to: assign, active: p.active !== false, firm_id: me.firm_id,
      subject: (p.subject ?? "").trim() || null,
      delay_days: every,
    };
    if (p.id) {
      // Never re-key or un-scope a walker row. Campaign and step_key stay put.
      const { error } = await admin.from("drip_rules").update(row).eq("id", p.id);
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
      return NextResponse.json({ ok: true, id: p.id });
    }
    const campaign = (p.campaign || "").trim() || null;
    if (campaign) {
      row.campaign = campaign;
      row.step_key = dripStepKey(name);
      if (campaign === M6_DRIP_CAMPAIGN) row.assign_to = assign || "both";
    }
    const { data, error } = await admin.from("drip_rules").insert(row).select("id").single();
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ ok: true, id: data.id });
  }

  if (p.op === "enroll") {
    // The enrollment belongs to the TARGET lead: load it, use ITS firm (never
    // the operator's), and report a real failure instead of a blind ok
    // (Astra rounds 4-5: caller-supplied identity was forwarded unchecked and
    // RPC errors were swallowed).
    const leadId = String(p.lead_id || "");
    if (!leadId) return NextResponse.json({ error: "lead_id required" }, { status: 400 });
    const admin = supabaseAdmin();
    const { data: lead, error: leadErr } = await admin.from("leads").select("id, firm_id").eq("id", leadId).maybeSingle();
    if (leadErr) return NextResponse.json({ error: leadErr.message }, { status: 500 });
    if (!lead) return NextResponse.json({ error: "Lead not found." }, { status: 404 });
    const { error } = await admin.rpc("enroll_drips_for_lead", { p_lead: lead.id, p_firm: lead.firm_id });
    if (error) return NextResponse.json({ error: `Enrollment failed: ${error.message}` }, { status: 500 });
    return NextResponse.json({ ok: true });
  }

  if (p.op === "process") {
    const admin = supabaseAdmin();
    const { data: due } = await sb.from("drips_due").select("*").limit(100);
    let fired = 0;
    for (const d of due ?? []) {
      // Fire the touch. Call reminders just log; text/email attempt JustCall.
      if (d.channel === "sms" && d.phone) {
        await fetch(`${new URL(req.url).origin}/api/justcall`, {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "text", to: d.phone, body: d.template }),
        }).catch(() => {});
      }
      // Log a note + advance next_due by cadence.
      await admin.from("notes").insert({
        firm_id: d.firm_id, lead_id: d.lead_id, author_name: "Drip",
        scope: "file", body: `Auto ${d.channel} drip "${d.name}" fired.`,
      });
      await admin.from("drip_enrollments").update({
        last_sent: new Date().toISOString(),
        next_due: new Date(Date.now() + d.every_days * 86400000).toISOString().slice(0, 10),
      }).eq("id", d.enrollment_id);
      fired++;
    }
    return NextResponse.json({ ok: true, fired });
  }

  return NextResponse.json({ error: "unknown op" }, { status: 400 });
}
